const { Events, EmbedBuilder } = require('discord.js');
/** @type {import('../lib/types/index.ts').Event} */

module.exports = {
    name: 'onMessage', event: Events.MessageCreate, once: false,

    async execute(client, message) {
        const clientPrefix = client.prefix || process.env.CLIENT_PREFIX || '?';

        if (message.channel.type !== 0) return;
        if (message.author.bot || !message.guild || !message.content.toLowerCase().startsWith(clientPrefix.toLowerCase())) return;

        const [cmd, ...args] = message.content.slice(clientPrefix.length).trim().split(/ +/g);
        const Command = client.messageCommands.get(cmd.toLowerCase()) || client.messageCommands.find(c => c.alias?.includes(cmd.toLowerCase()));

        if (!Command) return;

        const embed = new EmbedBuilder().setColor('Red')
        if (Command.devOnly && !client.developer.includes(message.author.id)) return;
        if (Command.userPermissions && Command.userPermissions.length !== 0) {
            if (!message.member.permissions.has(Command.userPermissions)) return message.reply({ embeds: [embed.setDescription(`You need \`${Array.isArray(Command.userPermissions) ? Command.userPermissions.join(", ") : Command.userPermissions}\` permission(s) to execute this command!`)] });
        } if (Command.botPermissions && Command.botPermissions.length !== 0) {
            if (!message.guild.members.me.permissions.has(Command.botPermissions)) return message.reply({ embeds: [embed.setDescription(`I need \`${Array.isArray(Command.botPermissions) ? Command.botPermissions.join(", ") : Command.botPermissions}\` permission(s) to execute this command!`)] });
        }
        Command.execute(client, message, args);
    }
}
