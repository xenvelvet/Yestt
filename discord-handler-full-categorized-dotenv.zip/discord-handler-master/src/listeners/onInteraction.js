const { Events, EmbedBuilder } = require('discord.js');
/** @type {import('../lib/types/index.ts').Event} */

module.exports = {
    name: 'onInteraction', event: Events.InteractionCreate, once: false,

    async execute(client, interaction) {
        if (
            !interaction.isChatInputCommand() && !interaction.isContextMenuCommand() && !interaction.isAutocomplete()
        ) return;

        if (!interaction.guild) return;
        const Command = client.slashCommands.get(interaction.commandName);

        if (!Command) return;

        const embed = new EmbedBuilder().setColor('Red')
        if (Command.devOnly && !client.developer.includes(interaction.user.id)) return interaction.reply({ embeds: [embed.setDescription(`Warning! Access Restricted Developer Command Detected.`)], ephemeral: true });
        if (Command.userPermissions && Command.userPermissions.length !== 0) {
            if (!interaction.member.permissions.has(Command.userPermissions)) return interaction.reply({ embeds: [embed.setDescription(`You need \`${Array.isArray(Command.userPermissions) ? Command.userPermissions.join(', ') : Command.userPermissions}\` permission(s) to execute this command!`)], ephemeral: true });
        } if (Command.botPermissions && Command.botPermissions.length !== 0) {
            if (!interaction.guild.members.me.permissions.has(Command.botPermissions)) return interaction.reply({ embeds: [embed.setDescription(`I need \`${Array.isArray(Command.botPermissions) ? Command.botPermissions.join(', ') : Command.botPermissions}\` permission(s) to execute this command!`)], ephemeral: true });
        }
        Command.execute(client, interaction);
    }
}
